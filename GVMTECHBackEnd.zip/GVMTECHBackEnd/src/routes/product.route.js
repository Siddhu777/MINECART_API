const express = require('express')
const router = express.Router()

const productController = require('../controllers/product.controller');

router.get('/',productController.AllProducts);

// router.get('/images/:id',productController.AllProductsImages);

router.post('/',productController.createProduct);

module.exports = router